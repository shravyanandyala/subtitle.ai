import React, { useEffect } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';

import './App.css';
import Dashboard from '../Dashboard/Dashboard';
import Login from '../Login/Login';

import useToken from './useToken';

function App() {
  const { token, setToken } = useToken();
  const navigate = useNavigate();

  useEffect(() => {
    if (token) {
      navigate('/dashboard');
    }
  }, [token, navigate]);

  return (
      <div className="wrapper">
        <h1>Application</h1>
        <Routes>
          <Route 
            path="/" 
            element={token ? <Navigate to="/dashboard" /> : <Login setToken={setToken} />} 
          />
          <Route 
            path="/dashboard" 
            element={token ? <Dashboard /> : <Navigate to="/" />} 
          />
          {/* Redirect all other paths to login/dashboard depending on authentication */}
          <Route 
            path="*" 
            element={token ? <Navigate to="/dashboard" /> : <Navigate to="/" />} 
          />
        </Routes>
      </div>
  );
}

export default App;